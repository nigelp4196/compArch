#include<stdio.h>
#include<stdlib.h>
#define tempInt 10000
#define error "error file not found"

typedef struct linkedList{
    int value;
    struct linkedList *next;
}Hash;
void delete(Hash** head, int val)
{
    if(*head == NULL)
        return;
    if((*head)->value == val)
    {
        if((*head)->next == NULL)
        {
            Hash* ptr = *head;
            *head = NULL;
            free(ptr);
            return;
        }
        Hash* ptr = *head;
        (*head) = (*head)->next;
        free(ptr);
        return;
    }

    Hash* ptr = *head;
        while(ptr != NULL)
    {
        Hash* next = ptr->next;
        if(next != NULL && next->value == val)
        {
            ptr->next = next->next;
            free(next);
            return;
        } 
        ptr = ptr->next;  
    }
}

Hash* hashBucket[10000];

Hash* makeNode(int value){

    Hash *node = (Hash*)calloc(1,sizeof(Hash));

    node->value = value;

    node->next = NULL;

    return node;

}
void freeList(Hash** head)
{
    
    Hash* ptr = *head;

    while(ptr != NULL)
    {
        Hash* temp = ptr;
        ptr = ptr->next;
        free(temp);
    }
}
int addNode(int number){
int counterNode;
    for(int i=0;i<number;i++){
        counterNode++;
   }      
    int hashValue = number % 10000;

    if(hashValue < 0){

        hashValue += 10000;

    }

    int counter=0;
    int duplicateCounter=0;


    if(hashBucket[hashValue]==NULL){

        hashBucket[hashValue] = makeNode(number);

        counter = 0;

    }

    else{

        counter = 1;
        Hash *pre=NULL, *cur=hashBucket[hashValue];
        while(cur!=NULL){
            if(cur->value == number){
                duplicateCounter = 1;
                break;
            }
            pre= cur;
            cur= cur->next;
        }
        if(duplicateCounter == 0){
            pre->next = makeNode(number);
        }
    }
    return counter;
}


int search(int num){
    int hashValue = num % 10000;
    if(hashValue < 0){
        hashValue += 10000;
    }
    Hash *temp= hashBucket[hashValue];
    int valueFound=0;
    while(temp!=NULL){
        if(temp->value==num){
            valueFound = 1;
        }
        temp=temp->next;
    }
    return valueFound;
}



int main(int argc,char *argv[]){
    
        FILE * pf;
        pf = fopen (argv[1], "r");
        if(pf == NULL){
            printf(error);
            exit(1);
        }
        else{
            int number;
            char choice;
            int count1=0, count2=0;
           

            int a=0;
            while(a<10000){
                hashBucket[a]=NULL;
                a++;
            }


            int x=fscanf(pf, "%c\t%d\n", &choice, &number);
            while(x==2){
                if(choice=='i' || choice == 'I'){
                    count1 += addNode(number);
                }
                else if(choice=='s' || choice=='S'){
                    count2 += search(number);
                }
                x=fscanf(pf, "%c\t%d\n", &choice, &number) ;
            }
            printf("%d\n%d\n",count1,count2);
            fclose(pf);
            //freeList();
        }
    
    return 0;
}
