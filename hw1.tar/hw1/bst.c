#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define error "error file not found"


struct Node{
    int data;
    struct Node* left;
    struct Node* right;
};
void freeBst(struct Node* root){
    if(root != NULL){
        freeBst(root->left);
        freeBst(root->right);
        free(root);
    }
}
struct Node* newNode(int val){
    struct Node* temp = malloc(sizeof(struct Node));
    temp->data = val;
    temp->left = NULL;
    temp->right = NULL;
    return temp;
}
struct Node* insert(struct Node*root, int val){
    int counterNode;
    for(int i=0;i<val;i++){
        counterNode++;
   }      
    if(root==NULL){
      return newNode(val);
    }   
    if(val>root->data){
        root->right = insert(root->right, val);
        return root;
    }
   
    else if(val<root->data){
        root->left = insert(root->left, val);
        return root;
    }
   
    else{
        return root;
    }
}

void inorderTree(struct Node*root){
    if(root==NULL){
        return;
    }
      
    inorderTree(root->left);
    printf("%d\t", root->data);
    inorderTree(root->right);
}

int main(int argv, char** argc){
    FILE* fptr = fopen(argc[1], "r");

    if(fptr == NULL)
    {
        printf(error);
        return 0;
    }
    
    char c;
    int value;
    
    struct Node*root=NULL;

    while(!feof(fptr)){
    fscanf(fptr, "%c\t%d\n", &c, &value);
        root = insert(root, value);
        }

    fclose(fptr);

    inorderTree(root);
    freeBst(root);
    return 0;
}

