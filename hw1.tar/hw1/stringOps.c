#include <stdio.h>
#include <string.h>
#define error "error file not found"


int main(int argc, char* argv[])
{



    char buff[1024];
    strcpy(buff, argv[1]);
    
   int counter=0,i,l;
   for (l = 0; buff[l] != '\0'; ++l);
   
   for(i=0;i<l;i++) 
   {
       if(buff[i]=='a' || buff[i]=='e' || buff[i]=='i' ||buff[i]=='o' ||buff[i]=='u' || buff[i]=='A' || buff[i]=='E' || buff[i]=='I' ||buff[i]=='O' ||buff[i]=='U' )
       {
           buff[counter++]=buff[i];
       }
   }
   buff[counter]='\0';
   printf("%s",buff); 



    return 0;

}
