#include <stdio.h>
#include <stdlib.h>

typedef struct Node
{
    int data;
    struct Node* next;
} Node;

void add(Node** head, int val)
{
    if(*head == NULL)
    {
        Node* newNode = (Node*) malloc(sizeof(Node));
        newNode->data = val;
        newNode->next = NULL;
        *head = newNode;
        return;
    }

    if(val <= (*head)->data)
    {
        Node* newNode = (Node*) malloc(sizeof(Node));
        newNode->data = val;
        newNode->next = *head;
        *head = newNode;
        return;
    }

    Node* ptr = *head;
    Node* prev = NULL;

    while(ptr != NULL)
    {
        if(val <= ptr->data)
        {
            Node* newNode = (Node*) malloc(sizeof(Node));
            newNode->data = val;
            prev->next = newNode;
            newNode->next = ptr;
            return;
        }
        prev = ptr;
        ptr = ptr->next;
    }

    if(ptr == NULL)
    {
        Node* newNode = (Node*) malloc(sizeof(Node));
        newNode->data = val;
        prev->next = newNode;
        newNode->next = NULL;
        return;
    }
}

void delete(Node** head, int val)
{
    if(*head == NULL)
        return;
    if((*head)->data == val)
    {
        if((*head)->next == NULL)
        {
            Node* ptr = *head;
            *head = NULL;
            free(ptr);
            return;
        }
        Node* ptr = *head;
        (*head) = (*head)->next;
        free(ptr);
        return;
    }

    Node* ptr = *head;
        while(ptr != NULL)
    {
        Node* next = ptr->next;
        if(next != NULL && next->data == val)
        {
            ptr->next = next->next;
            free(next);
            return;
        } 
        ptr = ptr->next;  
    }
}

void freeList(Node** head)
{
    
    Node* ptr = *head;

    while(ptr != NULL)
    {
        Node* curr = ptr;
        ptr = ptr->next;
        free(curr);
    }
}
int main(int argv, char** argc)
{
    Node* linkedList = NULL;

    FILE* file = fopen(argc[1], "r");

    if(file == NULL)
    {
        printf("error");
        return 0;
    }

    char x;
    int y;

    while(!feof(file))
    {
        fscanf(file, "%c\t%d\n", &x, &y);
        if(x == 'i')
            add(&linkedList, y);
        if(x == 'd')
            delete(&linkedList, y);
    }

   //printList(&linkedList);
        
    Node* ptr = linkedList;
    
    Node* counter = ptr;
    int sizeOfLink = 0;

    while(counter != NULL)
    {
        sizeOfLink++;
        counter = counter->next;
    }


    int size = sizeOfLink;
    printf("%d\n", size);
    while(ptr != NULL)
    {
        printf("%d\t", ptr->data);
        int val = ptr->data;
        while(ptr != NULL && val == ptr->data)
            ptr = ptr->next;
    }


    freeList(&linkedList);
    fclose(file);

    printf("\n");

    return 0;
}
