#include <stdio.h>
#include <stdlib.h>
#define error "error file not found"

void sortArrayAccending(int* arr, int n){
        int even[n];
        int odd[n];
        int counter1=0;
        int counter2=0;
        for(int i =0;i<n;i++){
            if(arr[i]%2==0){
                even[counter1]=arr[i];
                counter1++;
            }else{
                odd[counter2]=arr[i];
                counter2++;
                }
        }
        //printArray(odd,counter2);
 int temp;
 for(int i=0;i<counter1;++i){
        
        
        for(int a=i+1;a<counter1;++a)
            if(even[i]>even[a]){
                temp = even[i];
                even[i]=even[a];
                even[a]=temp;

            }

      //  printf("%d ", even[i]);
        }

for(int i=0;i<counter2;i++){
        for(int a=i+1;a<counter2;++a)
            if(odd[i]<odd[a]){
                temp = odd[i];
                odd[i]=odd[a];
                odd[a]=temp;

            }
       // printf("%d ", odd[i]);
       
                        }
      
                   
   for(int i=0;i<counter1;i++){
 printf("%d\t", even[i]);

   }       

    for(int i=0;i<counter2;i++){
 printf("%d\t", odd[i]);

   }       
    



}




int main(int argc, char* argv[]){
//printf("hello worl2d\n");


int size, i;

FILE *fptr;


    if(fptr == NULL)
    {
        printf(error);
        return 0;
    }
if ((fptr = fopen(argv[1], "r")) == NULL){

printf("Error! opening file");
exit(1);
}
fscanf(fptr,"%d", &size);
int arr[size];
for(i = 0; i < size; i++){
    fscanf(fptr, "%d", &arr[i]);
}
fclose(fptr);
   // printArray(arr,size);
    sortArrayAccending(arr,size);


}


